    </main>

    <!-- Bottom Navigation (Mobile) -->
    <nav class="bottom-nav">
        <a href="index.php" class="bottom-nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>">
            <i class="fas fa-home"></i>
            <span>Home</span>
        </a>
        
        <a href="products.php" class="bottom-nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'products.php' ? 'active' : ''; ?>">
            <i class="fas fa-box"></i>
            <span>Products</span>
        </a>
        
        <a href="cart.php" class="bottom-nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'cart.php' ? 'active' : ''; ?>">
            <i class="fas fa-shopping-cart"></i>
            <span>Cart</span>
            <span class="cart-badge badge" style="display: none;">0</span>
        </a>
        
        <?php if (is_logged_in()): ?>
            <a href="profile.php" class="bottom-nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'profile.php' ? 'active' : ''; ?>">
                <i class="fas fa-user"></i>
                <span>Profile</span>
            </a>
        <?php else: ?>
            <a href="login.php" class="bottom-nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'login.php' ? 'active' : ''; ?>">
                <i class="fas fa-sign-in-alt"></i>
                <span>Login</span>
            </a>
        <?php endif; ?>
    </nav>

    <!-- Footer (Desktop) -->
    <footer class="footer desktop-only">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>AA DIGITS</h3>
                    <p>Premium digital products, templates, and software solutions for modern businesses and developers.</p>
                    <div class="social-links">
                        <a href="#" title="Facebook"><i class="fab fa-facebook"></i></a>
                        <a href="#" title="Twitter"><i class="fab fa-twitter"></i></a>
                        <a href="#" title="Instagram"><i class="fab fa-instagram"></i></a>
                        <a href="#" title="LinkedIn"><i class="fab fa-linkedin"></i></a>
                    </div>
                </div>
                
                <div class="footer-section">
                    <h4>Products</h4>
                    <ul>
                        <li><a href="products.php?category=web-templates">Web Templates</a></li>
                        <li><a href="products.php?category=mobile-apps">Mobile Apps</a></li>
                        <li><a href="products.php?category=graphics-design">Graphics & Design</a></li>
                        <li><a href="products.php?category=software-tools">Software Tools</a></li>
                    </ul>
                </div>
                
                <div class="footer-section">
                    <h4>Support</h4>
                    <ul>
                        <li><a href="faq.php">FAQ</a></li>
                        <li><a href="contact.php">Contact Us</a></li>
                        <li><a href="support.php">Support Center</a></li>
                        <li><a href="refund-policy.php">Refund Policy</a></li>
                    </ul>
                </div>
                
                <div class="footer-section">
                    <h4>Company</h4>
                    <ul>
                        <li><a href="about.php">About Us</a></li>
                        <li><a href="privacy-policy.php">Privacy Policy</a></li>
                        <li><a href="terms-of-service.php">Terms of Service</a></li>
                        <li><a href="careers.php">Careers</a></li>
                    </ul>
                </div>
            </div>
            
            <div class="footer-bottom">
                <div class="footer-bottom-content">
                    <p>&copy; <?php echo date('Y'); ?> AA DIGITS. All rights reserved.</p>
                    <div class="payment-methods">
                        <i class="fab fa-cc-visa" title="Visa"></i>
                        <i class="fab fa-cc-mastercard" title="Mastercard"></i>
                        <i class="fab fa-cc-paypal" title="PayPal"></i>
                        <i class="fab fa-cc-stripe" title="Stripe"></i>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!-- Notification Container -->
    <div id="notification-container"></div>

    <!-- Scripts -->
    <script src="assets/js/app.js"></script>
    
    <!-- Additional Scripts -->
    <?php if (isset($additional_js)): ?>
        <?php foreach ($additional_js as $js): ?>
            <script src="<?php echo $js; ?>"></script>
        <?php endforeach; ?>
    <?php endif; ?>
    
    <!-- Inline Scripts -->
    <?php if (isset($inline_js)): ?>
        <script>
            <?php echo $inline_js; ?>
        </script>
    <?php endif; ?>

    <style>
    /* Footer Styles */
    .footer {
        background: var(--bg-secondary);
        border-top: 1px solid var(--border-color);
        padding: var(--spacing-2xl) 0 var(--spacing-lg);
        margin-top: var(--spacing-2xl);
    }

    .footer-content {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: var(--spacing-xl);
        margin-bottom: var(--spacing-xl);
    }

    .footer-section h3,
    .footer-section h4 {
        color: var(--text-primary);
        margin-bottom: var(--spacing-md);
        font-weight: 600;
    }

    .footer-section p {
        color: var(--text-secondary);
        line-height: 1.6;
        margin-bottom: var(--spacing-md);
    }

    .footer-section ul {
        list-style: none;
    }

    .footer-section ul li {
        margin-bottom: var(--spacing-sm);
    }

    .footer-section ul li a {
        color: var(--text-secondary);
        text-decoration: none;
        transition: color var(--transition-fast);
    }

    .footer-section ul li a:hover {
        color: var(--primary-color);
    }

    .social-links {
        display: flex;
        gap: var(--spacing-md);
    }

    .social-links a {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 40px;
        height: 40px;
        background: var(--bg-tertiary);
        color: var(--text-secondary);
        border-radius: 50%;
        text-decoration: none;
        transition: all var(--transition-fast);
    }

    .social-links a:hover {
        background: var(--primary-color);
        color: white;
        transform: translateY(-2px);
    }

    .footer-bottom {
        border-top: 1px solid var(--border-color);
        padding-top: var(--spacing-lg);
    }

    .footer-bottom-content {
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: var(--spacing-md);
    }

    .footer-bottom p {
        color: var(--text-secondary);
        margin: 0;
    }

    .payment-methods {
        display: flex;
        gap: var(--spacing-md);
        font-size: 1.5rem;
    }

    .payment-methods i {
        color: var(--text-muted);
        transition: color var(--transition-fast);
    }

    .payment-methods i:hover {
        color: var(--primary-color);
    }

    /* Mobile Menu Styles */
    .mobile-menu {
        position: fixed;
        top: 0;
        left: -100%;
        width: 280px;
        height: 100vh;
        background: var(--bg-card);
        z-index: 1001;
        transition: left var(--transition-normal);
        box-shadow: var(--shadow-xl);
    }

    .mobile-menu.active {
        left: 0;
    }

    .mobile-menu-content {
        padding: var(--spacing-lg);
        height: 100%;
        overflow-y: auto;
    }

    .mobile-menu-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: var(--spacing-xl);
        padding-bottom: var(--spacing-lg);
        border-bottom: 1px solid var(--border-color);
    }

    .mobile-menu-header h3 {
        margin: 0;
        color: var(--text-primary);
    }

    .mobile-menu-close {
        background: none;
        border: none;
        font-size: 1.25rem;
        color: var(--text-primary);
        cursor: pointer;
        padding: var(--spacing-sm);
        border-radius: var(--radius-md);
    }

    .mobile-menu-nav a {
        display: flex;
        align-items: center;
        padding: var(--spacing-md);
        color: var(--text-primary);
        text-decoration: none;
        border-radius: var(--radius-md);
        margin-bottom: var(--spacing-sm);
        transition: background-color var(--transition-fast);
        gap: var(--spacing-md);
    }

    .mobile-menu-nav a:hover {
        background: var(--bg-tertiary);
    }

    .mobile-menu-nav hr {
        border: none;
        border-top: 1px solid var(--border-color);
        margin: var(--spacing-lg) 0;
    }

    /* User Menu Styles */
    .user-menu {
        position: relative;
    }

    .user-menu-toggle {
        display: flex;
        align-items: center;
        gap: var(--spacing-sm);
    }

    .user-menu-dropdown {
        position: absolute;
        top: 100%;
        right: 0;
        background: var(--bg-card);
        border: 1px solid var(--border-color);
        border-radius: var(--radius-md);
        box-shadow: var(--shadow-lg);
        min-width: 200px;
        z-index: 1000;
        opacity: 0;
        visibility: hidden;
        transform: translateY(-10px);
        transition: all var(--transition-fast);
    }

    .user-menu:hover .user-menu-dropdown {
        opacity: 1;
        visibility: visible;
        transform: translateY(0);
    }

    .user-menu-dropdown a {
        display: flex;
        align-items: center;
        padding: var(--spacing-md);
        color: var(--text-primary);
        text-decoration: none;
        transition: background-color var(--transition-fast);
        gap: var(--spacing-sm);
    }

    .user-menu-dropdown a:hover {
        background: var(--bg-tertiary);
    }

    .user-menu-dropdown hr {
        border: none;
        border-top: 1px solid var(--border-color);
        margin: var(--spacing-sm) 0;
    }

    /* Notification Styles */
    .notification {
        position: fixed;
        top: 20px;
        right: 20px;
        background: var(--bg-card);
        border: 1px solid var(--border-color);
        border-radius: var(--radius-md);
        box-shadow: var(--shadow-lg);
        padding: var(--spacing-md);
        z-index: 1002;
        max-width: 400px;
        animation: slideInRight 0.3s ease-out;
    }

    .notification-success {
        border-left: 4px solid var(--success-color);
    }

    .notification-error {
        border-left: 4px solid var(--error-color);
    }

    .notification-warning {
        border-left: 4px solid var(--warning-color);
    }

    .notification-info {
        border-left: 4px solid var(--primary-color);
    }

    .notification-content {
        display: flex;
        align-items: center;
        gap: var(--spacing-sm);
    }

    .notification-close {
        position: absolute;
        top: var(--spacing-sm);
        right: var(--spacing-sm);
        background: none;
        border: none;
        color: var(--text-muted);
        cursor: pointer;
        font-size: 0.875rem;
    }

    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }

    /* Form Error Styles */
    .form-control.error {
        border-color: var(--error-color);
        box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.1);
    }

    .field-error {
        color: var(--error-color);
        font-size: 0.875rem;
        margin-top: var(--spacing-xs);
    }

    /* Desktop Only */
    .desktop-only {
        display: none;
    }

    @media (min-width: 768px) {
        .desktop-only {
            display: block;
        }
    }
    </style>
</body>
</html>
