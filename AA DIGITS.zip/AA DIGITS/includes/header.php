<?php
require_once 'config/config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title . ' - ' . SITE_NAME : SITE_NAME . ' - Digital Products Store'; ?></title>
    <meta name="description" content="<?php echo isset($page_description) ? $page_description : 'AA DIGITS - Premium digital products, templates, and software solutions'; ?>">
    
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="assets/images/favicon.ico">
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Main CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
    
    <!-- Additional CSS -->
    <?php if (isset($additional_css)): ?>
        <?php foreach ($additional_css as $css): ?>
            <link rel="stylesheet" href="<?php echo $css; ?>">
        <?php endforeach; ?>
    <?php endif; ?>
    
    <!-- Meta Tags -->
    <meta property="og:title" content="<?php echo isset($page_title) ? $page_title . ' - ' . SITE_NAME : SITE_NAME; ?>">
    <meta property="og:description" content="<?php echo isset($page_description) ? $page_description : 'Premium digital products and templates'; ?>">
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo SITE_URL . $_SERVER['REQUEST_URI']; ?>">
    <meta property="og:image" content="<?php echo SITE_URL; ?>/assets/images/og-image.jpg">
    
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo isset($page_title) ? $page_title . ' - ' . SITE_NAME : SITE_NAME; ?>">
    <meta name="twitter:description" content="<?php echo isset($page_description) ? $page_description : 'Premium digital products and templates'; ?>">
    <meta name="twitter:image" content="<?php echo SITE_URL; ?>/assets/images/og-image.jpg">
</head>
<body>
    <!-- Mobile App Bar -->
    <div class="mobile-app-bar">
        <a href="index.php" class="logo">
            <i class="fas fa-cube"></i> AA DIGITS
        </a>
        <div class="app-bar-actions">
            <button class="theme-toggle" title="Toggle theme">
                <i class="fas fa-moon"></i>
            </button>
            <button class="menu-btn" title="Menu">
                <i class="fas fa-bars"></i>
            </button>
        </div>
    </div>

    <!-- Desktop Navigation -->
    <nav class="desktop-nav">
        <div class="nav-container">
            <a href="index.php" class="logo">
                <i class="fas fa-cube"></i> AA DIGITS
            </a>
            
            <ul class="nav-links">
                <li><a href="index.php">Home</a></li>
                <li><a href="products.php">Products</a></li>
                <li><a href="categories.php">Categories</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
            
            <div class="nav-actions">
                <button class="theme-toggle" title="Toggle theme">
                    <i class="fas fa-moon"></i>
                </button>
                
                <?php if (is_logged_in()): ?>
                    <a href="cart.php" class="btn btn-outline">
                        <i class="fas fa-shopping-cart"></i>
                        <span class="cart-badge badge" style="display: none;">0</span>
                    </a>
                    <div class="user-menu">
                        <button class="btn btn-secondary user-menu-toggle">
                            <i class="fas fa-user"></i>
                            <?php echo $_SESSION['user_name']; ?>
                            <i class="fas fa-chevron-down"></i>
                        </button>
                        <div class="user-menu-dropdown">
                            <a href="profile.php"><i class="fas fa-user"></i> Profile</a>
                            <a href="orders.php"><i class="fas fa-box"></i> Orders</a>
                            <a href="downloads.php"><i class="fas fa-download"></i> Downloads</a>
                            <?php if (is_admin()): ?>
                                <a href="admin/"><i class="fas fa-cog"></i> Admin</a>
                            <?php endif; ?>
                            <hr>
                            <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                        </div>
                    </div>
                <?php else: ?>
                    <a href="login.php" class="btn btn-outline">Login</a>
                    <a href="register.php" class="btn btn-primary">Sign Up</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <!-- Mobile Menu Overlay -->
    <div class="mobile-menu">
        <div class="mobile-menu-content">
            <div class="mobile-menu-header">
                <h3>Menu</h3>
                <button class="mobile-menu-close">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <nav class="mobile-menu-nav">
                <a href="index.php"><i class="fas fa-home"></i> Home</a>
                <a href="products.php"><i class="fas fa-box"></i> Products</a>
                <a href="categories.php"><i class="fas fa-th-large"></i> Categories</a>
                <a href="about.php"><i class="fas fa-info-circle"></i> About</a>
                <a href="contact.php"><i class="fas fa-envelope"></i> Contact</a>
                
                <?php if (is_logged_in()): ?>
                    <hr>
                    <a href="profile.php"><i class="fas fa-user"></i> Profile</a>
                    <a href="orders.php"><i class="fas fa-box"></i> Orders</a>
                    <a href="downloads.php"><i class="fas fa-download"></i> Downloads</a>
                    <?php if (is_admin()): ?>
                        <a href="admin/"><i class="fas fa-cog"></i> Admin</a>
                    <?php endif; ?>
                    <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                <?php else: ?>
                    <hr>
                    <a href="login.php"><i class="fas fa-sign-in-alt"></i> Login</a>
                    <a href="register.php"><i class="fas fa-user-plus"></i> Sign Up</a>
                <?php endif; ?>
            </nav>
        </div>
    </div>

    <!-- Main Content -->
    <main class="main-content">
        <?php
        // Display flash messages
        if (isset($_SESSION['success'])):
        ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
            </div>
        <?php endif; ?>

        <?php
        if (isset($_SESSION['error'])):
        ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i>
                <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
            </div>
        <?php endif; ?>

        <?php
        if (isset($_SESSION['warning'])):
        ?>
            <div class="alert alert-warning">
                <i class="fas fa-exclamation-triangle"></i>
                <?php echo $_SESSION['warning']; unset($_SESSION['warning']); ?>
            </div>
        <?php endif; ?>
