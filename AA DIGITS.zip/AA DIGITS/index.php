<?php
$page_title = 'Home';
$page_description = 'AA DIGITS - Premium digital products, templates, and software solutions for modern businesses and developers.';

require_once 'config/config.php';
require_once 'classes/Product.php';

// Initialize product class
$product = new Product();

// Get featured products
try {
    $featured_products = $product->getFeaturedProducts(6);
} catch (Exception $e) {
    $featured_products = [];
}

// Get latest products
try {
    $latest_products = $product->getAllProducts(8, 0);
} catch (Exception $e) {
    $latest_products = [];
}

include 'includes/header.php';
?>

<!-- Hero Section -->
<section class="hero">
    <div class="container">
        <div class="hero-content fade-in">
            <h1>Premium Digital Products for Modern Creators</h1>
            <p>Discover high-quality templates, software, and digital resources to accelerate your projects and boost your productivity.</p>
            <div class="hero-actions">
                <a href="products.php" class="btn btn-primary btn-lg">
                    <i class="fas fa-rocket"></i>
                    Explore Products
                </a>
                <a href="#featured" class="btn btn-outline btn-lg">
                    <i class="fas fa-star"></i>
                    Featured Items
                </a>
            </div>
        </div>
    </div>
</section>

<!-- Search Section -->
<section class="section">
    <div class="container">
        <div class="search-section slide-up">
            <form action="products.php" method="GET" class="search-form">
                <div class="search-bar">
                    <i class="fas fa-search search-icon"></i>
                    <input type="text" name="search" class="form-control search-input" placeholder="Search for products, templates, software..." value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                    <button type="submit" class="btn btn-primary">Search</button>
                </div>
                <div class="search-suggestions" style="display: none;"></div>
            </form>
            
            <div class="popular-searches">
                <span>Popular:</span>
                <a href="products.php?search=website+template" class="search-tag">Website Templates</a>
                <a href="products.php?search=mobile+app" class="search-tag">Mobile Apps</a>
                <a href="products.php?search=logo+design" class="search-tag">Logo Design</a>
                <a href="products.php?search=wordpress" class="search-tag">WordPress</a>
            </div>
        </div>
    </div>
</section>

<!-- Featured Products -->
<?php if (!empty($featured_products)): ?>
<section id="featured" class="section">
    <div class="container">
        <div class="section-header slide-up">
            <h2 class="section-title">Featured Products</h2>
            <p class="section-subtitle">Hand-picked premium products that deliver exceptional value</p>
        </div>
        
        <div class="grid grid-cols-1 grid-md-2 grid-lg-3 slide-up">
            <?php foreach ($featured_products as $product_item): ?>
                <div class="product-card">
                    <div class="product-card-image">
                        <?php
                        $screenshots = json_decode($product_item['screenshots'], true);
                        $image_url = !empty($screenshots) ? $screenshots[0] : 'assets/images/placeholder-product.jpg';
                        ?>
                        <img src="<?php echo $image_url; ?>" alt="<?php echo htmlspecialchars($product_item['title']); ?>" loading="lazy">
                        <div class="product-card-badge">Featured</div>
                    </div>
                    
                    <div class="product-card-content">
                        <h3 class="product-card-title">
                            <a href="product.php?slug=<?php echo $product_item['slug']; ?>">
                                <?php echo htmlspecialchars($product_item['title']); ?>
                            </a>
                        </h3>
                        
                        <p class="product-card-description">
                            <?php echo htmlspecialchars($product_item['short_description']); ?>
                        </p>
                        
                        <div class="product-card-price">
                            <div class="price-info">
                                <?php if ($product_item['sale_price'] && $product_item['sale_price'] < $product_item['price']): ?>
                                    <span class="price-current"><?php echo format_price($product_item['sale_price']); ?></span>
                                    <span class="price-original"><?php echo format_price($product_item['price']); ?></span>
                                <?php else: ?>
                                    <span class="price-current"><?php echo format_price($product_item['price']); ?></span>
                                <?php endif; ?>
                            </div>
                            
                            <div class="product-rating">
                                <div class="stars">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </div>
                                <span class="rating-count">(<?php echo rand(15, 150); ?>)</span>
                            </div>
                        </div>
                        
                        <div class="product-card-actions">
                            <button class="btn btn-primary btn-full add-to-cart" data-product-id="<?php echo $product_item['id']; ?>">
                                <i class="fas fa-cart-plus"></i>
                                Add to Cart
                            </button>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        
        <div class="text-center mt-4">
            <a href="products.php?featured=1" class="btn btn-outline btn-lg">
                View All Featured Products
                <i class="fas fa-arrow-right"></i>
            </a>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- Categories Section -->
<section class="section" style="background: var(--bg-secondary);">
    <div class="container">
        <div class="section-header slide-up">
            <h2 class="section-title">Browse Categories</h2>
            <p class="section-subtitle">Find exactly what you need in our organized categories</p>
        </div>
        
        <div class="grid grid-cols-2 grid-md-3 grid-lg-6 slide-up">
            <a href="products.php?category=web-templates" class="category-card">
                <div class="category-icon">
                    <i class="fas fa-code"></i>
                </div>
                <h4>Web Templates</h4>
                <p>Professional website templates</p>
            </a>
            
            <a href="products.php?category=mobile-apps" class="category-card">
                <div class="category-icon">
                    <i class="fas fa-mobile-alt"></i>
                </div>
                <h4>Mobile Apps</h4>
                <p>iOS & Android app templates</p>
            </a>
            
            <a href="products.php?category=graphics-design" class="category-card">
                <div class="category-icon">
                    <i class="fas fa-palette"></i>
                </div>
                <h4>Graphics & Design</h4>
                <p>Logos, icons, and graphics</p>
            </a>
            
            <a href="products.php?category=software-tools" class="category-card">
                <div class="category-icon">
                    <i class="fas fa-tools"></i>
                </div>
                <h4>Software Tools</h4>
                <p>Utility and development tools</p>
            </a>
            
            <a href="products.php?category=ebooks" class="category-card">
                <div class="category-icon">
                    <i class="fas fa-book"></i>
                </div>
                <h4>E-books</h4>
                <p>Digital books and guides</p>
            </a>
            
            <a href="products.php?category=audio-music" class="category-card">
                <div class="category-icon">
                    <i class="fas fa-music"></i>
                </div>
                <h4>Audio & Music</h4>
                <p>Sound effects and music</p>
            </a>
        </div>
    </div>
</section>

<!-- Latest Products -->
<?php if (!empty($latest_products)): ?>
<section class="section">
    <div class="container">
        <div class="section-header slide-up">
            <h2 class="section-title">Latest Products</h2>
            <p class="section-subtitle">Fresh additions to our digital marketplace</p>
        </div>
        
        <div class="grid grid-cols-1 grid-md-2 grid-lg-4 slide-up">
            <?php foreach (array_slice($latest_products, 0, 8) as $product_item): ?>
                <div class="product-card">
                    <div class="product-card-image">
                        <?php
                        $screenshots = json_decode($product_item['screenshots'], true);
                        $image_url = !empty($screenshots) ? $screenshots[0] : 'assets/images/placeholder-product.jpg';
                        ?>
                        <img src="<?php echo $image_url; ?>" alt="<?php echo htmlspecialchars($product_item['title']); ?>" loading="lazy">
                        <div class="product-card-badge new">New</div>
                    </div>
                    
                    <div class="product-card-content">
                        <h3 class="product-card-title">
                            <a href="product.php?slug=<?php echo $product_item['slug']; ?>">
                                <?php echo htmlspecialchars($product_item['title']); ?>
                            </a>
                        </h3>
                        
                        <div class="product-card-price">
                            <div class="price-info">
                                <?php if ($product_item['sale_price'] && $product_item['sale_price'] < $product_item['price']): ?>
                                    <span class="price-current"><?php echo format_price($product_item['sale_price']); ?></span>
                                    <span class="price-original"><?php echo format_price($product_item['price']); ?></span>
                                <?php else: ?>
                                    <span class="price-current"><?php echo format_price($product_item['price']); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="product-card-actions">
                            <button class="btn btn-primary btn-sm btn-full add-to-cart" data-product-id="<?php echo $product_item['id']; ?>">
                                <i class="fas fa-cart-plus"></i>
                                Add to Cart
                            </button>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        
        <div class="text-center mt-4">
            <a href="products.php" class="btn btn-outline btn-lg">
                View All Products
                <i class="fas fa-arrow-right"></i>
            </a>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- Features Section -->
<section class="section" style="background: var(--bg-secondary);">
    <div class="container">
        <div class="section-header slide-up">
            <h2 class="section-title">Why Choose AA DIGITS?</h2>
            <p class="section-subtitle">We provide the best digital products with exceptional service</p>
        </div>
        
        <div class="grid grid-cols-1 grid-md-2 grid-lg-4 slide-up">
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-shield-alt"></i>
                </div>
                <h4>Secure Downloads</h4>
                <p>All products are scanned and verified for security before being made available.</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-download"></i>
                </div>
                <h4>Instant Access</h4>
                <p>Download your purchases immediately after successful payment completion.</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-headset"></i>
                </div>
                <h4>24/7 Support</h4>
                <p>Our dedicated support team is available around the clock to help you.</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-money-bill-wave"></i>
                </div>
                <h4>Money Back Guarantee</h4>
                <p>Not satisfied? Get a full refund within 30 days of your purchase.</p>
            </div>
        </div>
    </div>
</section>

<!-- Testimonials Section -->
<section class="section">
    <div class="container">
        <div class="section-header slide-up">
            <h2 class="section-title">What Our Customers Say</h2>
            <p class="section-subtitle">Join thousands of satisfied customers worldwide</p>
        </div>
        
        <div class="grid grid-cols-1 grid-md-2 grid-lg-3 slide-up">
            <div class="testimonial-card">
                <div class="testimonial-content">
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <p>"Amazing quality products and excellent customer service. The website templates saved me weeks of development time!"</p>
                </div>
                <div class="testimonial-author">
                    <img src="assets/images/testimonial-1.jpg" alt="Sarah Johnson" loading="lazy">
                    <div>
                        <h5>Sarah Johnson</h5>
                        <span>Web Developer</span>
                    </div>
                </div>
            </div>
            
            <div class="testimonial-card">
                <div class="testimonial-content">
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <p>"The mobile app templates are top-notch. Clean code, great documentation, and responsive design. Highly recommended!"</p>
                </div>
                <div class="testimonial-author">
                    <img src="assets/images/testimonial-2.jpg" alt="Mike Chen" loading="lazy">
                    <div>
                        <h5>Mike Chen</h5>
                        <span>App Developer</span>
                    </div>
                </div>
            </div>
            
            <div class="testimonial-card">
                <div class="testimonial-content">
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <p>"Fast downloads, secure payments, and great variety of products. AA DIGITS is my go-to marketplace for digital assets."</p>
                </div>
                <div class="testimonial-author">
                    <img src="assets/images/testimonial-3.jpg" alt="Emily Davis" loading="lazy">
                    <div>
                        <h5>Emily Davis</h5>
                        <span>Graphic Designer</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
/* Hero Actions */
.hero-actions {
    display: flex;
    gap: var(--spacing-md);
    justify-content: center;
    flex-wrap: wrap;
    margin-top: var(--spacing-xl);
}

/* Search Section */
.search-section {
    background: var(--bg-card);
    padding: var(--spacing-xl);
    border-radius: var(--radius-xl);
    box-shadow: var(--shadow-lg);
    border: 1px solid var(--border-color);
    margin-bottom: var(--spacing-xl);
}

.search-form {
    margin-bottom: var(--spacing-lg);
}

.search-bar {
    display: flex;
    gap: var(--spacing-md);
    align-items: center;
    flex-wrap: wrap;
}

.search-bar .form-control {
    flex: 1;
    min-width: 250px;
}

.search-suggestions {
    position: absolute;
    top: 100%;
    left: 0;
    right: 0;
    background: var(--bg-card);
    border: 1px solid var(--border-color);
    border-top: none;
    border-radius: 0 0 var(--radius-md) var(--radius-md);
    box-shadow: var(--shadow-lg);
    z-index: 100;
    max-height: 300px;
    overflow-y: auto;
}

.suggestion-item {
    display: flex;
    align-items: center;
    padding: var(--spacing-md);
    cursor: pointer;
    transition: background-color var(--transition-fast);
    gap: var(--spacing-sm);
}

.suggestion-item:hover {
    background: var(--bg-tertiary);
}

.popular-searches {
    display: flex;
    align-items: center;
    gap: var(--spacing-md);
    flex-wrap: wrap;
}

.popular-searches span {
    color: var(--text-secondary);
    font-weight: 500;
}

.search-tag {
    background: var(--bg-tertiary);
    color: var(--text-primary);
    padding: var(--spacing-xs) var(--spacing-md);
    border-radius: var(--radius-md);
    text-decoration: none;
    font-size: 0.875rem;
    transition: all var(--transition-fast);
}

.search-tag:hover {
    background: var(--primary-color);
    color: white;
}

/* Category Cards */
.category-card {
    background: var(--bg-card);
    padding: var(--spacing-xl);
    border-radius: var(--radius-lg);
    text-align: center;
    text-decoration: none;
    color: var(--text-primary);
    transition: all var(--transition-normal);
    border: 1px solid var(--border-color);
}

.category-card:hover {
    transform: translateY(-4px);
    box-shadow: var(--shadow-xl);
    border-color: var(--primary-color);
}

.category-icon {
    width: 60px;
    height: 60px;
    background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto var(--spacing-md);
    font-size: 1.5rem;
    color: white;
}

.category-card h4 {
    margin-bottom: var(--spacing-sm);
    font-size: 1.125rem;
}

.category-card p {
    color: var(--text-secondary);
    font-size: 0.875rem;
    margin: 0;
}

/* Feature Cards */
.feature-card {
    background: var(--bg-card);
    padding: var(--spacing-xl);
    border-radius: var(--radius-lg);
    text-align: center;
    border: 1px solid var(--border-color);
    transition: all var(--transition-normal);
}

.feature-card:hover {
    transform: translateY(-2px);
    box-shadow: var(--shadow-lg);
}

.feature-icon {
    width: 60px;
    height: 60px;
    background: linear-gradient(135deg, var(--accent-color), #f59e0b);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto var(--spacing-md);
    font-size: 1.5rem;
    color: white;
}

.feature-card h4 {
    margin-bottom: var(--spacing-sm);
    font-size: 1.125rem;
}

.feature-card p {
    color: var(--text-secondary);
    font-size: 0.875rem;
    margin: 0;
    line-height: 1.6;
}

/* Testimonial Cards */
.testimonial-card {
    background: var(--bg-card);
    padding: var(--spacing-xl);
    border-radius: var(--radius-lg);
    border: 1px solid var(--border-color);
    transition: all var(--transition-normal);
}

.testimonial-card:hover {
    transform: translateY(-2px);
    box-shadow: var(--shadow-lg);
}

.testimonial-content {
    margin-bottom: var(--spacing-lg);
}

.testimonial-content .stars {
    color: var(--accent-color);
    margin-bottom: var(--spacing-md);
}

.testimonial-content p {
    font-style: italic;
    color: var(--text-secondary);
    line-height: 1.6;
    margin: 0;
}

.testimonial-author {
    display: flex;
    align-items: center;
    gap: var(--spacing-md);
}

.testimonial-author img {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    object-fit: cover;
}

.testimonial-author h5 {
    margin: 0;
    font-size: 1rem;
    font-weight: 600;
}

.testimonial-author span {
    color: var(--text-secondary);
    font-size: 0.875rem;
}

/* Product Rating */
.product-rating {
    display: flex;
    align-items: center;
    gap: var(--spacing-sm);
}

.stars {
    color: var(--accent-color);
    font-size: 0.875rem;
}

.rating-count {
    color: var(--text-muted);
    font-size: 0.75rem;
}

/* Badge Variations */
.product-card-badge.new {
    background: var(--success-color);
}

/* Mobile Responsive */
@media (max-width: 767px) {
    .hero h1 {
        font-size: 2rem;
    }
    
    .hero-actions {
        flex-direction: column;
        align-items: center;
    }
    
    .hero-actions .btn {
        width: 100%;
        max-width: 300px;
    }
    
    .search-bar {
        flex-direction: column;
    }
    
    .search-bar .form-control,
    .search-bar .btn {
        width: 100%;
    }
    
    .popular-searches {
        justify-content: center;
    }
}
</style>

<?php include 'includes/footer.php'; ?>
