<?php
// Redirect to admin dashboard
header('Location: admin/');
exit();
?>
