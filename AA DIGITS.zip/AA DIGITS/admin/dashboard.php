<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AA DIGITS - Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f8fafc;
            color: #1e293b;
        }
        
        .admin-header {
            background: #1e40af;
            color: white;
            padding: 1rem 2rem;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .admin-header h1 {
            font-size: 1.5rem;
            font-weight: 600;
        }
        
        .admin-container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 1rem;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .stat-card {
            background: white;
            padding: 1.5rem;
            border-radius: 8px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            border-left: 4px solid #3b82f6;
        }
        
        .stat-card h3 {
            font-size: 2rem;
            font-weight: 700;
            color: #1e40af;
            margin-bottom: 0.5rem;
        }
        
        .stat-card p {
            color: #64748b;
            font-weight: 500;
        }
        
        .admin-nav {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 2rem;
        }
        
        .nav-card {
            background: white;
            padding: 1.5rem;
            border-radius: 8px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            text-align: center;
            text-decoration: none;
            color: #1e293b;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        
        .nav-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }
        
        .nav-card i {
            font-size: 2rem;
            color: #3b82f6;
            margin-bottom: 1rem;
        }
        
        .nav-card h3 {
            font-size: 1.1rem;
            margin-bottom: 0.5rem;
        }
        
        .nav-card p {
            color: #64748b;
            font-size: 0.9rem;
        }
        
        .recent-section {
            background: white;
            padding: 1.5rem;
            border-radius: 8px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        
        .recent-section h2 {
            margin-bottom: 1rem;
            color: #1e40af;
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .table th,
        .table td {
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid #e2e8f0;
        }
        
        .table th {
            background: #f8fafc;
            font-weight: 600;
            color: #475569;
        }
        
        .status-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.75rem;
            font-weight: 500;
        }
        
        .status-active {
            background: #dcfce7;
            color: #166534;
        }
        
        .status-pending {
            background: #fef3c7;
            color: #92400e;
        }
        
        .logout-btn {
            position: fixed;
            top: 1rem;
            right: 1rem;
            background: #dc2626;
            color: white;
            padding: 0.5rem 1rem;
            border: none;
            border-radius: 6px;
            text-decoration: none;
            font-size: 0.9rem;
        }
        
        .logout-btn:hover {
            background: #b91c1c;
        }
    </style>
</head>
<body>
    <div class="admin-header">
        <h1><i class="fas fa-tachometer-alt"></i> AA DIGITS Admin Dashboard</h1>
    </div>
    
    <a href="../logout.php" class="logout-btn">
        <i class="fas fa-sign-out-alt"></i> Logout
    </a>
    
    <div class="admin-container">
        <!-- Stats Cards -->
        <div class="stats-grid">
            <div class="stat-card">
                <h3>156</h3>
                <p>Total Products</p>
            </div>
            <div class="stat-card">
                <h3>1,234</h3>
                <p>Total Users</p>
            </div>
            <div class="stat-card">
                <h3>89</h3>
                <p>Total Orders</p>
            </div>
            <div class="stat-card">
                <h3>$12,450</h3>
                <p>Total Revenue</p>
            </div>
        </div>
        
        <!-- Navigation Cards -->
        <div class="admin-nav">
            <a href="simple-products.php" class="nav-card">
                <i class="fas fa-box"></i>
                <h3>Manage Products</h3>
                <p>Add, edit, and delete products</p>
            </a>
            
            <a href="simple-users.php" class="nav-card">
                <i class="fas fa-users"></i>
                <h3>Manage Users</h3>
                <p>View and manage user accounts</p>
            </a>
            
            <a href="simple-orders.php" class="nav-card">
                <i class="fas fa-shopping-cart"></i>
                <h3>View Orders</h3>
                <p>Track and manage orders</p>
            </a>
            
            <a href="simple-categories.php" class="nav-card">
                <i class="fas fa-tags"></i>
                <h3>Categories</h3>
                <p>Organize product categories</p>
            </a>
            
            <a href="../index.php" class="nav-card">
                <i class="fas fa-home"></i>
                <h3>View Website</h3>
                <p>Go to main website</p>
            </a>
            
            <a href="simple-settings.php" class="nav-card">
                <i class="fas fa-cog"></i>
                <h3>Settings</h3>
                <p>Configure website settings</p>
            </a>
        </div>
        
        <!-- Recent Activity -->
        <div class="recent-section">
            <h2>Recent Activity</h2>
            <table class="table">
                <thead>
                    <tr>
                        <th>Activity</th>
                        <th>User</th>
                        <th>Status</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>New product added: "Modern Website Template"</td>
                        <td>Admin User</td>
                        <td><span class="status-badge status-active">Active</span></td>
                        <td>2 hours ago</td>
                    </tr>
                    <tr>
                        <td>User registration: john@example.com</td>
                        <td>John Doe</td>
                        <td><span class="status-badge status-pending">Pending</span></td>
                        <td>4 hours ago</td>
                    </tr>
                    <tr>
                        <td>Order completed: #ORD-001</td>
                        <td>Jane Smith</td>
                        <td><span class="status-badge status-active">Completed</span></td>
                        <td>1 day ago</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
