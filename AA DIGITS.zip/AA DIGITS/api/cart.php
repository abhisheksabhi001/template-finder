<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../config/config.php';

// Initialize cart in session if not exists
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

$response = ['success' => false, 'message' => '', 'data' => null];

try {
    $method = $_SERVER['REQUEST_METHOD'];
    
    if ($method === 'GET') {
        $action = $_GET['action'] ?? '';
        
        switch ($action) {
            case 'count':
                $count = array_sum($_SESSION['cart']);
                $response = ['success' => true, 'count' => $count];
                break;
                
            case 'items':
                $response = ['success' => true, 'items' => $_SESSION['cart']];
                break;
                
            case 'total':
                // Calculate total (would need product prices from database)
                $total = 0;
                // TODO: Fetch product prices and calculate total
                $response = ['success' => true, 'total' => $total];
                break;
                
            default:
                $response['message'] = 'Invalid action';
        }
        
    } elseif ($method === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true);
        $action = $input['action'] ?? '';
        $product_id = $input['product_id'] ?? null;
        
        if (!$product_id) {
            $response['message'] = 'Product ID is required';
        } else {
            switch ($action) {
                case 'add':
                    if (!isset($_SESSION['cart'][$product_id])) {
                        $_SESSION['cart'][$product_id] = 0;
                    }
                    $_SESSION['cart'][$product_id]++;
                    $response = [
                        'success' => true, 
                        'message' => 'Product added to cart',
                        'count' => array_sum($_SESSION['cart'])
                    ];
                    break;
                    
                case 'remove':
                    if (isset($_SESSION['cart'][$product_id])) {
                        unset($_SESSION['cart'][$product_id]);
                        $response = [
                            'success' => true, 
                            'message' => 'Product removed from cart',
                            'count' => array_sum($_SESSION['cart'])
                        ];
                    } else {
                        $response['message'] = 'Product not found in cart';
                    }
                    break;
                    
                case 'update':
                    $quantity = $input['quantity'] ?? 1;
                    if ($quantity > 0) {
                        $_SESSION['cart'][$product_id] = $quantity;
                        $response = [
                            'success' => true, 
                            'message' => 'Cart updated',
                            'count' => array_sum($_SESSION['cart'])
                        ];
                    } else {
                        unset($_SESSION['cart'][$product_id]);
                        $response = [
                            'success' => true, 
                            'message' => 'Product removed from cart',
                            'count' => array_sum($_SESSION['cart'])
                        ];
                    }
                    break;
                    
                case 'clear':
                    $_SESSION['cart'] = [];
                    $response = [
                        'success' => true, 
                        'message' => 'Cart cleared',
                        'count' => 0
                    ];
                    break;
                    
                default:
                    $response['message'] = 'Invalid action';
            }
        }
    } else {
        $response['message'] = 'Method not allowed';
    }
    
} catch (Exception $e) {
    $response['message'] = 'An error occurred: ' . $e->getMessage();
}

echo json_encode($response);
?>
