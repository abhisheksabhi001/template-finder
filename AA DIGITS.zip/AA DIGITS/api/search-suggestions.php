<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../classes/Product.php';

$response = [];

try {
    $query = $_GET['q'] ?? '';
    
    if (strlen($query) >= 2) {
        $product = new Product();
        $database = new Database();
        $conn = $database->getConnection();
        
        // Search for products matching the query
        $sql = "SELECT id, title, slug FROM products 
                WHERE (title LIKE ? OR tags LIKE ?) 
                AND is_active = 1 
                ORDER BY title ASC 
                LIMIT 10";
        
        $stmt = $conn->prepare($sql);
        $search_term = "%$query%";
        $stmt->execute([$search_term, $search_term]);
        
        $suggestions = [];
        while ($row = $stmt->fetch()) {
            $suggestions[] = [
                'id' => $row['id'],
                'title' => $row['title'],
                'slug' => $row['slug']
            ];
        }
        
        $response = $suggestions;
    }
    
} catch (Exception $e) {
    $response = ['error' => 'An error occurred while fetching suggestions'];
}

echo json_encode($response);
?>
