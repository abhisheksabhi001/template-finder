<?php
require_once __DIR__ . '/../config/config.php';

class User {
    private $conn;
    private $table_name = "users";

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function register($name, $email, $password) {
        $query = "INSERT INTO " . $this->table_name . " (name, email, password) VALUES (?, ?, ?)";
        $stmt = $this->conn->prepare($query);
        
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        if ($stmt->execute([$name, $email, $hashed_password])) {
            return $this->conn->lastInsertId();
        }
        return false;
    }

    public function login($email, $password) {
        $query = "SELECT id, name, email, password, is_admin, role FROM " . $this->table_name . " WHERE email = ? AND is_active = 1";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$email]);
        
        if ($stmt->rowCount() > 0) {
            $user = $stmt->fetch();
            if (password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['name'];
                $_SESSION['user_email'] = $user['email'];
                $_SESSION['is_admin'] = $user['is_admin'];
                $_SESSION['user_role'] = $user['role'];
                return $user;
            }
        }
        return false;
    }

    public function logout() {
        session_destroy();
        return true;
    }

    public function getUserById($id) {
        $query = "SELECT id, name, email, phone, created_at FROM " . $this->table_name . " WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    public function updateProfile($id, $name, $email, $phone = null) {
        $query = "UPDATE " . $this->table_name . " SET name = ?, email = ?, phone = ? WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([$name, $email, $phone, $id]);
    }

    public function changePassword($id, $new_password) {
        $query = "UPDATE " . $this->table_name . " SET password = ? WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        return $stmt->execute([$hashed_password, $id]);
    }

    public function emailExists($email, $exclude_id = null) {
        $query = "SELECT id FROM " . $this->table_name . " WHERE email = ?";
        $params = [$email];
        
        if ($exclude_id) {
            $query .= " AND id != ?";
            $params[] = $exclude_id;
        }
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute($params);
        return $stmt->rowCount() > 0;
    }

    public function generateResetToken($email) {
        $token = generate_token();
        $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));
        
        $query = "UPDATE " . $this->table_name . " SET reset_token = ?, reset_token_expires = ? WHERE email = ?";
        $stmt = $this->conn->prepare($query);
        
        if ($stmt->execute([$token, $expires, $email])) {
            return $token;
        }
        return false;
    }

    public function resetPassword($token, $new_password) {
        $query = "SELECT id FROM " . $this->table_name . " WHERE reset_token = ? AND reset_token_expires > NOW()";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$token]);
        
        if ($stmt->rowCount() > 0) {
            $user = $stmt->fetch();
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            
            $update_query = "UPDATE " . $this->table_name . " SET password = ?, reset_token = NULL, reset_token_expires = NULL WHERE id = ?";
            $update_stmt = $this->conn->prepare($update_query);
            return $update_stmt->execute([$hashed_password, $user['id']]);
        }
        return false;
    }

    public function getAllUsers($limit = 50, $offset = 0) {
        $query = "SELECT id, name, email, phone, is_active, created_at FROM " . $this->table_name . " ORDER BY created_at DESC LIMIT ? OFFSET ?";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$limit, $offset]);
        return $stmt->fetchAll();
    }

    public function toggleUserStatus($id) {
        $query = "UPDATE " . $this->table_name . " SET is_active = NOT is_active WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([$id]);
    }
}
?>
