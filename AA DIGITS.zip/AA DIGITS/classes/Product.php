<?php
require_once __DIR__ . '/../config/config.php';

class Product {
    private $conn;
    private $table_name = "products";

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function getAllProducts($limit = 12, $offset = 0, $category_id = null, $search = null, $featured = false) {
        $query = "SELECT p.*, c.name as category_name FROM " . $this->table_name . " p 
                  LEFT JOIN categories c ON p.category_id = c.id 
                  WHERE p.is_active = 1";
        $params = [];

        if ($category_id) {
            $query .= " AND p.category_id = ?";
            $params[] = $category_id;
        }

        if ($search) {
            $query .= " AND (p.title LIKE ? OR p.description LIKE ? OR p.tags LIKE ?)";
            $search_term = "%$search%";
            $params[] = $search_term;
            $params[] = $search_term;
            $params[] = $search_term;
        }

        if ($featured) {
            $query .= " AND p.is_featured = 1";
        }

        $query .= " ORDER BY p.created_at DESC LIMIT " . (int)$limit . " OFFSET " . (int)$offset;

        $stmt = $this->conn->prepare($query);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function getProductById($id) {
        $query = "SELECT p.*, c.name as category_name FROM " . $this->table_name . " p 
                  LEFT JOIN categories c ON p.category_id = c.id 
                  WHERE p.id = ? AND p.is_active = 1";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    public function getProductBySlug($slug) {
        $query = "SELECT p.*, c.name as category_name FROM " . $this->table_name . " p 
                  LEFT JOIN categories c ON p.category_id = c.id 
                  WHERE p.slug = ? AND p.is_active = 1";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$slug]);
        return $stmt->fetch();
    }

    public function getFeaturedProducts($limit = 6) {
        return $this->getAllProducts($limit, 0, null, null, true);
    }

    public function getRelatedProducts($category_id, $exclude_id, $limit = 4) {
        $query = "SELECT p.*, c.name as category_name FROM " . $this->table_name . " p 
                  LEFT JOIN categories c ON p.category_id = c.id 
                  WHERE p.category_id = ? AND p.id != ? AND p.is_active = 1 
                  ORDER BY RAND() LIMIT ?";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$category_id, $exclude_id, $limit]);
        return $stmt->fetchAll();
    }

    public function createProduct($data) {
        $query = "INSERT INTO " . $this->table_name . " 
                  (title, slug, description, short_description, price, sale_price, category_id, 
                   file_path, file_size, demo_url, screenshots, tags, is_featured, meta_title, meta_description) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $this->conn->prepare($query);
        
        if ($stmt->execute([
            $data['title'],
            $data['slug'],
            $data['description'],
            $data['short_description'],
            $data['price'],
            $data['sale_price'],
            $data['category_id'],
            $data['file_path'],
            $data['file_size'],
            $data['demo_url'],
            $data['screenshots'],
            $data['tags'],
            $data['is_featured'],
            $data['meta_title'],
            $data['meta_description']
        ])) {
            return $this->conn->lastInsertId();
        }
        return false;
    }

    public function updateProduct($id, $data) {
        $query = "UPDATE " . $this->table_name . " SET 
                  title = ?, slug = ?, description = ?, short_description = ?, price = ?, 
                  sale_price = ?, category_id = ?, file_path = ?, file_size = ?, demo_url = ?, 
                  screenshots = ?, tags = ?, is_featured = ?, meta_title = ?, meta_description = ? 
                  WHERE id = ?";
        
        $stmt = $this->conn->prepare($query);
        
        return $stmt->execute([
            $data['title'],
            $data['slug'],
            $data['description'],
            $data['short_description'],
            $data['price'],
            $data['sale_price'],
            $data['category_id'],
            $data['file_path'],
            $data['file_size'],
            $data['demo_url'],
            $data['screenshots'],
            $data['tags'],
            $data['is_featured'],
            $data['meta_title'],
            $data['meta_description'],
            $id
        ]);
    }

    public function deleteProduct($id) {
        $query = "DELETE FROM " . $this->table_name . " WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([$id]);
    }

    public function toggleProductStatus($id) {
        $query = "UPDATE " . $this->table_name . " SET is_active = NOT is_active WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([$id]);
    }

    public function incrementDownloadCount($id) {
        $query = "UPDATE " . $this->table_name . " SET downloads_count = downloads_count + 1 WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([$id]);
    }

    public function generateSlug($title) {
        $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $title)));
        
        // Check if slug exists
        $query = "SELECT id FROM " . $this->table_name . " WHERE slug = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$slug]);
        
        if ($stmt->rowCount() > 0) {
            $counter = 1;
            do {
                $new_slug = $slug . '-' . $counter;
                $stmt->execute([$new_slug]);
                $counter++;
            } while ($stmt->rowCount() > 0);
            $slug = $new_slug;
        }
        
        return $slug;
    }

    public function getProductsCount($category_id = null, $search = null) {
        $query = "SELECT COUNT(*) as total FROM " . $this->table_name . " WHERE is_active = 1";
        $params = [];

        if ($category_id) {
            $query .= " AND category_id = ?";
            $params[] = $category_id;
        }

        if ($search) {
            $query .= " AND (title LIKE ? OR description LIKE ? OR tags LIKE ?)";
            $search_term = "%$search%";
            $params[] = $search_term;
            $params[] = $search_term;
            $params[] = $search_term;
        }

        $stmt = $this->conn->prepare($query);
        $stmt->execute($params);
        $result = $stmt->fetch();
        return $result['total'];
    }
}
?>
