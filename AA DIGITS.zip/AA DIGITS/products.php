<?php
$page_title = 'Products';
$page_description = 'Browse our collection of premium digital products, templates, and software solutions.';

require_once 'config/config.php';
require_once 'classes/Product.php';

// Initialize product class
$product = new Product();

// Get filter parameters
$search = $_GET['search'] ?? '';
$category_param = $_GET['category'] ?? '';
$sort = $_GET['sort'] ?? 'newest';
$page = max(1, intval($_GET['page'] ?? 1));
$per_page = 12;
$offset = ($page - 1) * $per_page;

// Handle category parameter (could be ID or slug)
$category_id = null;
if ($category_param) {
    if (is_numeric($category_param)) {
        $category_id = $category_param;
    } else {
        // Convert slug to ID
        $database = new Database();
        $conn = $database->getConnection();
        $stmt = $conn->prepare("SELECT id FROM categories WHERE slug = ? OR name = ? LIMIT 1");
        $stmt->execute([$category_param, ucwords(str_replace('-', ' ', $category_param))]);
        $category_result = $stmt->fetch();
        if ($category_result) {
            $category_id = $category_result['id'];
        }
    }
}

// Get products based on filters
$products = $product->getAllProducts($per_page, $offset, $category_id, $search);
$total_products = $product->getProductsCount($category_id, $search);
$total_pages = ceil($total_products / $per_page);

// Get categories for filter
$database = new Database();
$conn = $database->getConnection();
$categories_stmt = $conn->query("SELECT * FROM categories WHERE is_active = 1 ORDER BY name");
$categories = $categories_stmt->fetchAll();

include 'includes/header.php';
?>

<!-- Page Header -->
<section class="page-header">
    <div class="container">
        <div class="page-header-content">
            <h1>Digital Products</h1>
            <p>Discover premium templates, software, and digital resources</p>
            <nav class="breadcrumb">
                <a href="index.php">Home</a>
                <i class="fas fa-chevron-right"></i>
                <span>Products</span>
            </nav>
        </div>
    </div>
</section>

<!-- Filters Section -->
<section class="section">
    <div class="container">
        <div class="filters">
            <form method="GET" class="filter-form">
                <div class="filter-row">
                    <div class="search-bar">
                        <i class="fas fa-search search-icon"></i>
                        <input type="text" name="search" class="form-control search-input" 
                               placeholder="Search products..." value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    
                    <div class="filter-group">
                        <select name="category" class="form-control">
                            <option value="">All Categories</option>
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?php echo $cat['id']; ?>" 
                                        <?php echo $category_id == $cat['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($cat['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <select name="sort" class="form-control">
                            <option value="newest" <?php echo $sort == 'newest' ? 'selected' : ''; ?>>Newest First</option>
                            <option value="oldest" <?php echo $sort == 'oldest' ? 'selected' : ''; ?>>Oldest First</option>
                            <option value="price_low" <?php echo $sort == 'price_low' ? 'selected' : ''; ?>>Price: Low to High</option>
                            <option value="price_high" <?php echo $sort == 'price_high' ? 'selected' : ''; ?>>Price: High to Low</option>
                            <option value="popular" <?php echo $sort == 'popular' ? 'selected' : ''; ?>>Most Popular</option>
                        </select>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-filter"></i>
                        Filter
                    </button>
                </div>
            </form>
        </div>
        
        <!-- Results Info -->
        <div class="results-info">
            <div class="results-count">
                Showing <?php echo count($products); ?> of <?php echo $total_products; ?> products
                <?php if ($search): ?>
                    for "<strong><?php echo htmlspecialchars($search); ?></strong>"
                <?php endif; ?>
            </div>
            
            <div class="view-toggle">
                <button class="view-btn active" data-view="grid" title="Grid View">
                    <i class="fas fa-th"></i>
                </button>
                <button class="view-btn" data-view="list" title="List View">
                    <i class="fas fa-list"></i>
                </button>
            </div>
        </div>
        
        <!-- Products Grid -->
        <?php if (!empty($products)): ?>
            <div class="products-container">
                <div class="grid grid-cols-1 grid-md-2 grid-lg-3 products-grid">
                    <?php foreach ($products as $product_item): ?>
                        <div class="product-card fade-in">
                            <div class="product-card-image">
                                <?php
                                $screenshots = json_decode($product_item['screenshots'], true);
                                $image_url = !empty($screenshots) ? $screenshots[0] : 'assets/images/placeholder-product.jpg';
                                ?>
                                <img src="<?php echo $image_url; ?>" alt="<?php echo htmlspecialchars($product_item['title']); ?>" loading="lazy">
                                
                                <?php if ($product_item['is_featured']): ?>
                                    <div class="product-card-badge">Featured</div>
                                <?php endif; ?>
                                
                                <?php if ($product_item['sale_price'] && $product_item['sale_price'] < $product_item['price']): ?>
                                    <div class="product-card-badge sale">Sale</div>
                                <?php endif; ?>
                                
                                <div class="product-overlay">
                                    <a href="product.php?slug=<?php echo $product_item['slug']; ?>" class="btn btn-primary btn-sm">
                                        <i class="fas fa-eye"></i>
                                        View Details
                                    </a>
                                </div>
                            </div>
                            
                            <div class="product-card-content">
                                <div class="product-category">
                                    <?php echo htmlspecialchars($product_item['category_name'] ?? 'Uncategorized'); ?>
                                </div>
                                
                                <h3 class="product-card-title">
                                    <a href="product.php?slug=<?php echo $product_item['slug']; ?>">
                                        <?php echo htmlspecialchars($product_item['title']); ?>
                                    </a>
                                </h3>
                                
                                <p class="product-card-description">
                                    <?php echo htmlspecialchars($product_item['short_description']); ?>
                                </p>
                                
                                <div class="product-card-price">
                                    <div class="price-info">
                                        <?php if ($product_item['sale_price'] && $product_item['sale_price'] < $product_item['price']): ?>
                                            <span class="price-current"><?php echo format_price($product_item['sale_price']); ?></span>
                                            <span class="price-original"><?php echo format_price($product_item['price']); ?></span>
                                        <?php else: ?>
                                            <span class="price-current"><?php echo format_price($product_item['price']); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <div class="product-rating">
                                        <div class="stars">
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                        </div>
                                        <span class="rating-count">(<?php echo rand(15, 150); ?>)</span>
                                    </div>
                                </div>
                                
                                <div class="product-card-actions">
                                    <button class="btn btn-primary btn-full add-to-cart" data-product-id="<?php echo $product_item['id']; ?>">
                                        <i class="fas fa-cart-plus"></i>
                                        Add to Cart
                                    </button>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            
            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
                <div class="pagination-wrapper">
                    <nav class="pagination">
                        <?php if ($page > 1): ?>
                            <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page - 1])); ?>" class="pagination-btn">
                                <i class="fas fa-chevron-left"></i>
                                Previous
                            </a>
                        <?php endif; ?>
                        
                        <div class="pagination-numbers">
                            <?php
                            $start = max(1, $page - 2);
                            $end = min($total_pages, $page + 2);
                            
                            if ($start > 1): ?>
                                <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => 1])); ?>" class="pagination-number">1</a>
                                <?php if ($start > 2): ?>
                                    <span class="pagination-dots">...</span>
                                <?php endif; ?>
                            <?php endif; ?>
                            
                            <?php for ($i = $start; $i <= $end; $i++): ?>
                                <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $i])); ?>" 
                                   class="pagination-number <?php echo $i == $page ? 'active' : ''; ?>">
                                    <?php echo $i; ?>
                                </a>
                            <?php endfor; ?>
                            
                            <?php if ($end < $total_pages): ?>
                                <?php if ($end < $total_pages - 1): ?>
                                    <span class="pagination-dots">...</span>
                                <?php endif; ?>
                                <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $total_pages])); ?>" class="pagination-number"><?php echo $total_pages; ?></a>
                            <?php endif; ?>
                        </div>
                        
                        <?php if ($page < $total_pages): ?>
                            <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page + 1])); ?>" class="pagination-btn">
                                Next
                                <i class="fas fa-chevron-right"></i>
                            </a>
                        <?php endif; ?>
                    </nav>
                </div>
            <?php endif; ?>
            
        <?php else: ?>
            <!-- No Products Found -->
            <div class="no-products">
                <div class="no-products-content">
                    <i class="fas fa-search"></i>
                    <h3>No products found</h3>
                    <p>We couldn't find any products matching your criteria. Try adjusting your filters or search terms.</p>
                    <a href="products.php" class="btn btn-primary">
                        <i class="fas fa-refresh"></i>
                        Clear Filters
                    </a>
                </div>
            </div>
        <?php endif; ?>
    </div>
</section>

<style>
/* Page Header */
.page-header {
    background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-dark) 100%);
    color: white;
    padding: var(--spacing-2xl) 0;
    position: relative;
    overflow: hidden;
}

.page-header::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="grain" width="100" height="100" patternUnits="userSpaceOnUse"><circle cx="50" cy="50" r="1" fill="white" opacity="0.1"/></pattern></defs><rect width="100" height="100" fill="url(%23grain)"/></svg>');
    opacity: 0.1;
}

.page-header-content {
    position: relative;
    z-index: 1;
    text-align: center;
}

.page-header h1 {
    font-size: 2.5rem;
    font-weight: 700;
    margin-bottom: var(--spacing-sm);
}

.page-header p {
    font-size: 1.125rem;
    opacity: 0.9;
    margin-bottom: var(--spacing-lg);
}

.breadcrumb {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: var(--spacing-sm);
    font-size: 0.875rem;
}

.breadcrumb a {
    color: white;
    text-decoration: none;
    opacity: 0.8;
}

.breadcrumb a:hover {
    opacity: 1;
}

.breadcrumb i {
    opacity: 0.6;
    font-size: 0.75rem;
}

/* Results Info */
.results-info {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin: var(--spacing-xl) 0;
    flex-wrap: wrap;
    gap: var(--spacing-md);
}

.results-count {
    color: var(--text-secondary);
    font-size: 0.875rem;
}

.view-toggle {
    display: flex;
    gap: var(--spacing-xs);
}

.view-btn {
    background: var(--bg-secondary);
    border: 1px solid var(--border-color);
    color: var(--text-secondary);
    padding: var(--spacing-sm);
    border-radius: var(--radius-md);
    cursor: pointer;
    transition: all var(--transition-fast);
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.view-btn:hover,
.view-btn.active {
    background: var(--primary-color);
    color: white;
    border-color: var(--primary-color);
}

/* Product Overlay */
.product-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.7);
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transition: opacity var(--transition-normal);
}

.product-card:hover .product-overlay {
    opacity: 1;
}

/* Product Category */
.product-category {
    font-size: 0.75rem;
    color: var(--primary-color);
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: var(--spacing-xs);
}

/* Badge Variations */
.product-card-badge.sale {
    background: var(--error-color);
}

/* No Products */
.no-products {
    text-align: center;
    padding: var(--spacing-2xl) 0;
}

.no-products-content i {
    font-size: 4rem;
    color: var(--text-muted);
    margin-bottom: var(--spacing-lg);
}

.no-products-content h3 {
    font-size: 1.5rem;
    margin-bottom: var(--spacing-md);
    color: var(--text-primary);
}

.no-products-content p {
    color: var(--text-secondary);
    margin-bottom: var(--spacing-xl);
    max-width: 500px;
    margin-left: auto;
    margin-right: auto;
}

/* Pagination */
.pagination-wrapper {
    margin-top: var(--spacing-2xl);
    display: flex;
    justify-content: center;
}

.pagination {
    display: flex;
    align-items: center;
    gap: var(--spacing-sm);
    flex-wrap: wrap;
}

.pagination-btn,
.pagination-number {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: var(--spacing-sm) var(--spacing-md);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-md);
    color: var(--text-primary);
    text-decoration: none;
    transition: all var(--transition-fast);
    min-width: 44px;
    height: 44px;
    gap: var(--spacing-xs);
}

.pagination-btn:hover,
.pagination-number:hover {
    border-color: var(--primary-color);
    color: var(--primary-color);
}

.pagination-number.active {
    background: var(--primary-color);
    color: white;
    border-color: var(--primary-color);
}

.pagination-numbers {
    display: flex;
    align-items: center;
    gap: var(--spacing-xs);
}

.pagination-dots {
    color: var(--text-muted);
    padding: 0 var(--spacing-xs);
}

/* Mobile Responsive */
@media (max-width: 767px) {
    .page-header h1 {
        font-size: 2rem;
    }
    
    .filter-row {
        flex-direction: column;
    }
    
    .filter-group,
    .search-bar {
        width: 100%;
    }
    
    .results-info {
        flex-direction: column;
        align-items: flex-start;
    }
    
    .pagination {
        justify-content: center;
    }
    
    .pagination-numbers {
        order: -1;
        margin-bottom: var(--spacing-sm);
    }
}
</style>

<script>
// View toggle functionality
document.addEventListener('DOMContentLoaded', function() {
    const viewButtons = document.querySelectorAll('.view-btn');
    const productsGrid = document.querySelector('.products-grid');
    
    viewButtons.forEach(button => {
        button.addEventListener('click', function() {
            const view = this.getAttribute('data-view');
            
            // Update active button
            viewButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            
            // Update grid layout
            if (view === 'list') {
                productsGrid.classList.remove('grid-md-2', 'grid-lg-3');
                productsGrid.classList.add('grid-cols-1');
            } else {
                productsGrid.classList.remove('grid-cols-1');
                productsGrid.classList.add('grid-md-2', 'grid-lg-3');
            }
        });
    });
});
</script>

<?php include 'includes/footer.php'; ?>
