<?php
// Global Configuration
session_start();

// Site Configuration
define('SITE_NAME', 'AA DIGITS');
define('SITE_URL', 'http://localhost/AA%20DIGITS');
define('SITE_EMAIL', 'admin@aadigits.com');

// Database Configuration
require_once 'database.php';

// File Upload Configuration
define('UPLOAD_DIR', '../uploads/');
define('PRODUCT_FILES_DIR', '../uploads/products/');
define('PRODUCT_IMAGES_DIR', '../uploads/images/');
define('MAX_FILE_SIZE', 100 * 1024 * 1024); // 100MB

// Security Configuration
define('ENCRYPTION_KEY', 'ybt_digital_secret_key_2024');
define('JWT_SECRET', 'jwt_secret_key_ybt_digital');

// Payment Gateway Configuration
define('RAZORPAY_KEY_ID', '');
define('RAZORPAY_KEY_SECRET', '');
define('STRIPE_PUBLISHABLE_KEY', '');
define('STRIPE_SECRET_KEY', '');
define('PAYPAL_CLIENT_ID', '');
define('PAYPAL_CLIENT_SECRET', '');

// Email Configuration
define('SMTP_HOST', '');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', '');
define('SMTP_PASSWORD', '');

// Utility Functions
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

function generate_token($length = 32) {
    return bin2hex(random_bytes($length));
}

function format_price($price, $currency = 'USD') {
    return '$' . number_format($price, 2);
}

function time_ago($datetime) {
    $time = time() - strtotime($datetime);
    
    if ($time < 60) return 'just now';
    if ($time < 3600) return floor($time/60) . ' minutes ago';
    if ($time < 86400) return floor($time/3600) . ' hours ago';
    if ($time < 2592000) return floor($time/86400) . ' days ago';
    if ($time < 31536000) return floor($time/2592000) . ' months ago';
    return floor($time/31536000) . ' years ago';
}

function redirect($url) {
    header("Location: " . $url);
    exit();
}

function is_logged_in() {
    return isset($_SESSION['user_id']);
}

function is_admin() {
    return isset($_SESSION['user_id']) && isset($_SESSION['is_admin']) && $_SESSION['is_admin'];
}

function get_current_user_id() {
    return isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
}

// Error handling
function handle_error($message, $redirect_url = null) {
    $_SESSION['error'] = $message;
    if ($redirect_url) {
        redirect($redirect_url);
    }
}

function handle_success($message, $redirect_url = null) {
    $_SESSION['success'] = $message;
    if ($redirect_url) {
        redirect($redirect_url);
    }
}

// Create upload directories if they don't exist
if (!file_exists(UPLOAD_DIR)) {
    mkdir(UPLOAD_DIR, 0755, true);
}
if (!file_exists(PRODUCT_FILES_DIR)) {
    mkdir(PRODUCT_FILES_DIR, 0755, true);
}
if (!file_exists(PRODUCT_IMAGES_DIR)) {
    mkdir(PRODUCT_IMAGES_DIR, 0755, true);
}
?>
